# CSET485 Assignment 1: Adult Census Income

**Student:** Mohit Raj  
**Enrollment:** S24BCAU0046  
**Seed:** 46

## Project
This notebook compares a linear probability model and logistic regression on the UCI Adult Census Income dataset. It also explores subgroup differences, omitted-variable sensitivity, confident errors, and fairness metrics across decision thresholds.

## Run on Google Colab
1. Upload `CSET485_Assignment1_AdultIncome.ipynb` to Google Colab.
2. Run the notebook from top to bottom.
3. The notebook downloads the UCI dataset directly. No manual dataset upload is needed.

## Files
- `CSET485_Assignment1_AdultIncome.ipynb`: notebook with code and analysis.
- `requirements.txt`: Python dependencies.

## Important
The notebook is a reproducible implementation, but its results may differ from a separate written report if the cleaning rules or feature definitions differ. Re-run the notebook and ensure your submitted report uses matching results.
